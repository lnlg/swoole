<?php
var_dump(swoole_get_local_ip());
